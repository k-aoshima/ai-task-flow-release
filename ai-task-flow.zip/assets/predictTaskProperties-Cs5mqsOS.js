import{getAvailableGeminiModels as y}from"./geminiAPI-D2OyqxAR.js";const M=async(s,c,m={})=>{if(!s)throw new Error("APIキーが設定されていません");if(!c.trim())throw new Error("タスク名を入力してください");const{preferredModel:a,autoSwitch:l=!0,onModelSwitch:o}=m;try{const i=await y(s);let r=[];if(a){const t=i.filter(e=>e!==a);r=[a,...t]}else r=i;l||(r=[r[0]]);let n=null;for(const t of r)try{console.log(`モデル ${t} で実行中...`);const e=await f(s,c,t);return t!==r[0]&&o&&o(t),e}catch(e){if(n=e,!l)throw e;if(e.message.includes("429")||e.message.includes("Quota exceeded")||e.message.includes("503")||e.message.includes("Overloaded")||e.message.includes("404")||e.message.includes("not found")||e.message.includes("not supported")){console.warn(`モデル ${t} でエラーが発生しました (Retryable): ${e.message}. 次のモデルを試します。`);continue}throw e}throw n||new Error("全てのモデルでリクエストが失敗しました")}catch(i){return console.error("タスクプロパティ予測エラー:",i),{urgency:2,importance:3,contextKey:"None",estimatedTime:30,keywords:[]}}},f=async(s,c,m)=>{var e,d,p,g,u,h;const a=`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${s}`,l=`以下のタスクの緊急度、重要度、実行環境、推定所要時間を予測してください。

タスク: ${c}

以下のJSON形式で回答してください（JSONのみ、説明不要）:
{
  "urgency": 1-4の整数（1=低、2=中、3=高、4=緊急）,
  "importance": 1-5の整数（1=低、2=中低、3=中、4=中高、5=高）,
  "contextKey": "None" | "Development" | "Testing" | "DeployConsole" | "Documentation" | "Meeting" | "Review" | "Planning",
  "estimatedTime": 分単位の整数（5-480分の範囲）,
  "keywords": ["キーワード1", "キーワード2"]
}`,o=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:l}]}]})});if(!o.ok){const w=await o.json().catch(()=>({}));throw new Error(((e=w.error)==null?void 0:e.message)||`APIエラー: ${o.status}`)}let n=(((h=(u=(g=(p=(d=(await o.json()).candidates)==null?void 0:d[0])==null?void 0:p.content)==null?void 0:g.parts)==null?void 0:u[0])==null?void 0:h.text)||"").trim();n.startsWith("```")&&(n=n.replace(/^```(?:json)?\n?/,"").replace(/\n?```$/,""));const t=JSON.parse(n);return{urgency:Math.max(1,Math.min(4,t.urgency||2)),importance:Math.max(1,Math.min(5,t.importance||3)),contextKey:t.contextKey||"None",estimatedTime:Math.max(5,Math.min(480,t.estimatedTime||30)),keywords:t.keywords||[]}};export{M as predictTaskProperties};
